export function isUndefined(data: any) {
  // eslint-disable-next-line no-undefined
  return data === undefined;
}
