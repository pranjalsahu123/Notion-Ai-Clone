export interface WebDAVServiceConfig {
  origin: string;
  username: string;
  password: string;
}
