export interface GithubImageHostingOption {
  accessToken: string;
  repo: string;
  branch?: string;
  savePath: string;
}
