import '@/main/background.main.common';
import '@/service/permissions/firefox/firefoxPermissionsService';
import '@/service/webRequest/firefox/background/tabService';
import '@/main/background.main';
